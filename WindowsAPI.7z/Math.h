#pragma once
namespace Math
{
	double Distance(Vector2 p1, Vector2 p2);
};

